﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace $rootnamespace$
{
	/// <summary>
	/// Purpose:
	/// Created By: $username$
	/// Created On: $time$
	/// </summary>
	public class $safeitemname$
	{
		private readonly ILogger<$safeitemname$> logger;

		public $safeitemname$ (ILogger<$safeitemname$> logger)
		{
			this.logger=logger;
		}
	}
}
